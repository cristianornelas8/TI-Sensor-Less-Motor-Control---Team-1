/*
 * test_data.c
 *
 *  Created on: Feb 27, 2025
 *      Author: theha
 */

#include "test_data.h"
#include "f28p65x_device.h"
#include "f28p65x_examples.h"




void UART_Init() {
    EALLOW;

    CpuSysRegs.PCLKCR7.bit.SCI_B = 1;

     //GPIO for SCI_B
    GpioCtrlRegs.GPBMUX1.bit.GPIO38 = 1; // (Transmit)
    GpioCtrlRegs.GPBMUX2.bit.GPIO55 = 1; // (Receive)
    GpioCtrlRegs.GPBDIR.bit.GPIO38 = 1;  // TX as output
    GpioCtrlRegs.GPBDIR.bit.GPIO55 = 0;  // RX as input

    //SCI_B (UART)
    SciaRegs.SCICCR.all = 0x0007;  // 1 stop bit, 8-bit char
    SciaRegs.SCICTL1.all = 0x0003; // Enable TX, RX
    SciaRegs.SCICTL2.bit.TXINTENA = 1; // Enable TX interrup

    //Baud Rate check this fr
    SciaRegs.SCIHBAUD.all = 0x0001;
    SciaRegs.SCILBAUD.all = 44;

    //Enable UART
    SciaRegs.SCICTL1.bit.SWRESET = 1;

    EDIS
}


void UART_SendChar(char c) {
    while (SciaRegs.SCICTL2.bit.TXRDY == 0);
    SciaRegs.SCITXBUF.all = c;
}


void UART_SendString(char *str) {
    while (*str) {
        UART_SendChar(*str++);
    }
}
