/*
 * test_data.h
 *
 *  Created on: Feb 27, 2025
 *      Author: theha
 */

#ifndef TEST_DATA_H_
#define TEST_DATA_H_

void UART_Init(void);
void UART_SendChar(char c);
void UART_SendString(char *str);



#endif /* TEST_DATA_H_ */
