/*
 * FloatToStr.c
 *
 *  Created on: Mar 24, 2025
 *      Author: theha
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>


void reverse(char *str, int len) {
    int i = 0, j = len - 1;
    while (i < j) {
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

// Converts integer to string
int intToStr(int x, char str[], int d) {
    int i = 0+d;
    while (x) {
        str[i++] = (x % 10) + '0';
        x = x / 10;
    }

    // If number is 0
    if (i == 0) {
        str[i++] = '0';
    }

    str[i] = '\0';
    return i;
}

void ftoa(float n, char *res) {


    // Extract integer part
    int ipart = (int)n;

    int k =0;
    if (ipart <0) {
        ipart = abs(ipart);
        k = 1;
    }

    // Extract floating part
    float fpart = fabsf(n) - (float)ipart;

    fpart = fpart *10*10*10*10; // Shift float part
    fpart =(int)fpart;

    // Convert fractional part to string
    int i = intToStr(fpart, res, 0);

    res[i] = '.'; // Add decimal point

    // Convert integer part to string
    int j = intToStr(ipart, res, i+1);

    if(k == 1) {
        res[j] = '-';
    }
    res[j+k] = '\n';
    res[j+1+k] = '\r';
    res[j+2+k] = '\0';

    reverse(res, j+2+k);

}
//
// End of File
//

