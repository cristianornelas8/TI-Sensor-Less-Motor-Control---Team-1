/*
 * FloatToStr.h
 *
 *  Created on: Mar 24, 2025
 *      Author: theha
 */

#ifndef FLOATTOSTR_H_
#define FLOATTOSTR_H_

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

void reverse(char *str, int len);
int intToStr(int x, char str[], int d);
void f2str(float n, char *res);


#endif /* FLOATTOSTR_H_ */
