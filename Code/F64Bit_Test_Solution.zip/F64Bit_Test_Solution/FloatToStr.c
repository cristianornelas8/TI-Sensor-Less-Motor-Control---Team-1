/*
 * FloatToStr.c
 *
 *  Created on: Mar 24, 2025
 *      Author: theha
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>


void reverse(char *str, int len) { // flips the string
    int i = 0, j = len - 1;
    while (i < j) {
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

// convert int to string
int intToStr(int x, char str[], int d) {
    int i = 0 + d; // takes extra length for final decimal value
    while (x) {
        str[i++] = (x % 10) + '0';// adds to string that will end up backwards
        x = x / 10;
    }

    // If number is 0 adds zero
    if (i == 0) {
        str[i++] = '0';
    }

    str[i] = '\0'; // end the string
    return i;
}

void f2str(float n, char *res) {


    // grap int part xxxx.
    int ipart = (int)n;

    int k =0;
    if (ipart <0) {
        ipart = abs(ipart);
        k = 1; //grabs - from the #
    }

    // grab float part .xxxx
    float fpart = fabsf(n) - (float)ipart;

    fpart = fpart *10*10*10*10; // adds 4 dec point acc EX: 12.1234
    fpart =(int)fpart;

    // converts float part to string
    int i = intToStr(fpart, res, 0);

    res[i] = '.'; // adds decimal point to string

    // converts int part to string
    int j = intToStr(ipart, res, i+1);

    if(k == 1) {
        res[j] = '-'; //adds - to string if # was -
    }
    res[j+k] = '\n';
    res[j+1+k] = '\r';
    res[j+2+k] = '\0';

    reverse(res, j+2+k); // reverses the siring

}
//
// End of File
//

